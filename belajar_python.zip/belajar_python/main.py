#!/etc/bin/python
"""
  Autor : Fajri Fath
  Charset : UTF-8
"""
from module import fajri as pymysql
import time, os, sys, hashlib

db = pymysql.connect(
    host="localhost",
    user="root",
    passwd="rafi213fajri",
    database="keluarga"
  )

def show_data(db):
  print("Menampilkan data Anggota Keluarga")
  cursor = db.cursor()
  sql = "SELECT * FROM anggota"
  cursor.execute(sql)
  
  results = cursor.fetchall()
  for data in results:
    time.sleep(0.2)
    print("#######################################")
    print(data)

def insert_data(db):
  show_data(db)
  print("Menambahkan Anggota Keluarga")
  nama = input("Masukkan nama lengkap: ")
  tgl_lahir = input("Tanggal Lahir: ")
  info = input("Masukkan Info: ")
  #run 
  cursor = db.cursor()
  sql = "INSERT INTO anggota(nama, tgl_lahir, info) VALUES (%s, %s, %s)"
  val = (nama, tgl_lahir, info)
  
  cursor.execute(sql, val)
  db.commit()
  print("{} Data baru ditambahkan.".format(cursor.rowcount))
  main(db)

def update_data(db):
  show_data(db)
  print("Memperbarui Data Anggota")
  id = int(input("Pilih No ID yang akan diperbarui: "))
  nama = input("Nama lengkap baru: ")
  tgl_lahir = input("Tanggal Lahir baru: ")
  info = input("Info baru: ")
  
  cursor = db.cursor()
  sql = "UPDATE INTO anggota SET nama=%s, tgl_lahir=%s, info=%s WHERE id=%s"
  val = (id, nama, tgl_lahir, info)
  
  cursor.execute(sql, val)
  db.commit()
  print("{} Data berhasil diperbarui.".format(cursor.rowcount))
  main(db)

def delete_data(db):
  show_data(db)
  print("Menghapus Data Anggota Keluarga")
  id = input("Pilih No ID yang akan dihapus: ")
  
  cursor = db.cursor()
  sql = "DELETE FROM anggota WHERE id=%s"
  val = (id)
  cursor.execute(sql, val)
  db.commit()
  print("{} Data berhasil dihapus.".format(cursor.rowcount))
  main(db)

def main(db):
  time.sleep(2)
  print("\nWelcome to My Family")
  print("\n1.\tShow Data\n2.\tInsert Data\n3.\tUpdate Data\n4.\tDelete Data\n5.\tKeluar\n")
  pilih = input("Silahkan pilih menu(1-4): ")
  if pilih == '1':
    os.system('clear')
    show_data(db)
  elif pilih == '2':
    os.system('clear')
    insert_data(db)
  elif pilih == '3':
    os.system('clear')
    update_data(db)
  elif pilih == '4':
    os.system('clear')
    delete_data(db)
  elif pilih == '5':
    os.system('clear')
    sys.exit('GoodBye,Terimakasih')
  else:
    os.system('clear')
    sys.exit('Keyword yang anda gunakan salah')

if __name__ == "__main__":
  username = "fajhrinazgul"
  password = "7f841a0c2dba40722ae9f313534185b6"
  user = input('username: ')
  passwrd = input('password: ')
  awe = hashlib.md5(passwrd.encode()).hexdigest()
  if username == user or password == awe:
    print('Login Berhasil')
    main(db)