import json

file = open('js.json')

print(json.loads(file.read()))